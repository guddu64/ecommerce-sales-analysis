-- E-Commerce Sales Analysis SQL
-- Import data/ecommerce_orders.csv into a table named ecommerce_orders.
-- Suggested column types: dates as DATE, IDs/text as VARCHAR, measures as numeric.

-- 1. Overall KPIs
SELECT
    COUNT(DISTINCT order_id) AS total_orders,
    SUM(sales) AS total_sales,
    SUM(profit) AS total_profit,
    SUM(quantity) AS units_sold,
    COUNT(DISTINCT customer_id) AS unique_customers,
    ROUND(100.0 * SUM(profit) / NULLIF(SUM(sales), 0), 2) AS profit_margin_pct
FROM ecommerce_orders;

-- 2. Monthly sales and profit (PostgreSQL syntax)
SELECT
    DATE_TRUNC('month', CAST(order_date AS DATE)) AS sales_month,
    SUM(sales) AS total_sales,
    SUM(profit) AS total_profit,
    COUNT(DISTINCT order_id) AS orders
FROM ecommerce_orders
GROUP BY 1
ORDER BY 1;

-- 3. Category performance
SELECT
    category,
    SUM(sales) AS total_sales,
    SUM(profit) AS total_profit,
    SUM(quantity) AS units_sold
FROM ecommerce_orders
GROUP BY category
ORDER BY total_sales DESC;

-- 4. Region performance
SELECT
    region,
    SUM(sales) AS total_sales,
    SUM(profit) AS total_profit,
    COUNT(DISTINCT order_id) AS total_orders
FROM ecommerce_orders
GROUP BY region
ORDER BY total_profit DESC;

-- 5. Top 10 products by sales
SELECT product, SUM(sales) AS total_sales, SUM(profit) AS total_profit
FROM ecommerce_orders
GROUP BY product
ORDER BY total_sales DESC
LIMIT 10;

-- 6. Payment method mix
SELECT payment_method, COUNT(*) AS order_count, SUM(sales) AS total_sales
FROM ecommerce_orders
GROUP BY payment_method
ORDER BY order_count DESC;

-- 7. Monthly growth (PostgreSQL)
WITH monthly AS (
    SELECT DATE_TRUNC('month', CAST(order_date AS DATE)) AS sales_month,
           SUM(sales) AS total_sales
    FROM ecommerce_orders
    GROUP BY 1
)
SELECT sales_month, total_sales,
       LAG(total_sales) OVER (ORDER BY sales_month) AS previous_month_sales,
       ROUND(
           100.0 * (total_sales - LAG(total_sales) OVER (ORDER BY sales_month))
           / NULLIF(LAG(total_sales) OVER (ORDER BY sales_month), 0), 2
       ) AS month_over_month_growth_pct
FROM monthly
ORDER BY sales_month;
