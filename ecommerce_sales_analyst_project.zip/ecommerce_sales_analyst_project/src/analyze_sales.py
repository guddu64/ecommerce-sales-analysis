"""
E-Commerce Sales Performance Analysis
Dataset: synthetic demo data generated for this portfolio project.
Run: python src/analyze_sales.py
"""
from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data" / "ecommerce_orders.csv"
OUT = ROOT / "outputs"
OUT.mkdir(exist_ok=True)

df = pd.read_csv(DATA, parse_dates=["order_date"])

# Basic data-quality checks
print("Rows:", len(df))
print("Duplicate order IDs:", df["order_id"].duplicated().sum())
print("Missing values by column:\\n", df.isna().sum())
print("Date range:", df["order_date"].min().date(), "to", df["order_date"].max().date())

# KPI summary
kpis = pd.DataFrame([{
    "total_orders": df["order_id"].nunique(),
    "total_sales": round(df["sales"].sum(), 2),
    "total_profit": round(df["profit"].sum(), 2),
    "units_sold": int(df["quantity"].sum()),
    "unique_customers": df["customer_id"].nunique(),
    "profit_margin_pct": round(df["profit"].sum() / df["sales"].sum() * 100, 2),
}])
kpis.to_csv(OUT / "kpi_summary.csv", index=False)
print("\\nKPI summary:\\n", kpis.to_string(index=False))

# Monthly trend
df["month"] = df["order_date"].dt.to_period("M").astype(str)
monthly = df.groupby("month", as_index=False).agg(
    sales=("sales", "sum"), profit=("profit", "sum"), orders=("order_id", "nunique")
)
monthly.to_csv(OUT / "monthly_sales.csv", index=False)

# Category and region performance
category = df.groupby("category", as_index=False).agg(
    sales=("sales", "sum"), profit=("profit", "sum"), units=("quantity", "sum")
).sort_values("sales", ascending=False)
category.to_csv(OUT / "category_performance.csv", index=False)

region = df.groupby("region", as_index=False).agg(
    sales=("sales", "sum"), profit=("profit", "sum"), orders=("order_id", "nunique")
).sort_values("sales", ascending=False)
region.to_csv(OUT / "region_performance.csv", index=False)

# Visualizations
plt.figure(figsize=(10, 5))
plt.plot(monthly["month"], monthly["sales"], marker="o")
plt.title("Monthly Sales Trend")
plt.xlabel("Month")
plt.ylabel("Sales (INR)")
plt.xticks(rotation=45)
plt.tight_layout()
plt.savefig(OUT / "monthly_sales_trend.png", dpi=160)
plt.close()

plt.figure(figsize=(8, 5))
plt.bar(category["category"], category["sales"])
plt.title("Sales by Product Category")
plt.xlabel("Category")
plt.ylabel("Sales (INR)")
plt.xticks(rotation=20)
plt.tight_layout()
plt.savefig(OUT / "category_sales.png", dpi=160)
plt.close()

plt.figure(figsize=(8, 5))
plt.bar(region["region"], region["profit"])
plt.title("Profit by Region")
plt.xlabel("Region")
plt.ylabel("Profit (INR)")
plt.tight_layout()
plt.savefig(OUT / "region_profit.png", dpi=160)
plt.close()

print("\\nSaved summaries and charts in outputs/")
