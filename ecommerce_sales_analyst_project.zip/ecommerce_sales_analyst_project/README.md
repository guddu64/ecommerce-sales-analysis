# E-Commerce Sales Performance & Business Insights

## Project overview
Analyze e-commerce order data to identify sales trends, profitable product categories, regional performance, and payment-method patterns.

**Important:** `data/ecommerce_orders.csv` is synthetic sample data created for practice. It is not real company data. Do not present its findings as real business results.

## Tools
- Python, Pandas, Matplotlib
- SQL (example queries in `sql_queries.sql`)
- Power BI (dashboard build guide below)

## Dataset
The dataset has 1,200 sample orders and these fields:
- `order_id`, `order_date`, `customer_id`
- `region`, `category`, `product`
- `quantity`, `unit_price`, `unit_cost`, `sales`, `profit`
- `payment_method`

## Run the Python analysis
1. Install Python 3.10+.
2. Install dependencies: `pip install -r requirements.txt`
3. Run from the project root: `python src/analyze_sales.py`
4. Find summary CSVs and charts in `outputs/`.

## SQL practice
Import `data/ecommerce_orders.csv` into your database as `ecommerce_orders`, then run the queries in `sql_queries.sql`. Monthly date functions can vary by database; the included monthly examples use PostgreSQL syntax.

## Build a Power BI dashboard
1. Open Power BI Desktop and select **Get data → Text/CSV**.
2. Load `data/ecommerce_orders.csv`.
3. Set `order_date` to Date and numeric columns to appropriate numeric types.
4. Add KPI cards for Total Sales, Total Profit, Total Orders, Units Sold and Profit Margin.
5. Add a line chart: Axis = order_date (month), Values = Sum of sales.
6. Add a bar chart: Axis = category, Values = Sum of sales; another for region vs profit.
7. Add slicers for region, category and payment method.
8. Add a table for product, sales and profit; sort by sales descending.
9. Check that slicers filter all relevant visuals and format currency as INR.
10. Save as `ecommerce_sales_dashboard.pbix` and add screenshots to your portfolio.

Suggested DAX measures:
```DAX
Total Sales = SUM(ecommerce_orders[sales])
Total Profit = SUM(ecommerce_orders[profit])
Total Orders = DISTINCTCOUNT(ecommerce_orders[order_id])
Units Sold = SUM(ecommerce_orders[quantity])
Profit Margin % = DIVIDE([Total Profit], [Total Sales], 0)
Unique Customers = DISTINCTCOUNT(ecommerce_orders[customer_id])
```

## Resume bullet (use after you understand and verify the work)
**E-Commerce Sales Analysis | SQL, Python, Power BI**
- Analyzed 1,200 synthetic e-commerce orders using Python/Pandas and SQL to evaluate sales, profit, product categories and regional performance.
- Built reusable KPI summaries and visualizations; documented a Power BI dashboard with interactive slicers and business metrics.
- Identified category and regional patterns in the sample dataset and translated them into actionable business questions.

Only claim the Power BI dashboard is completed after you actually build and save the `.pbix` file.

## Interview questions to prepare
1. What is the difference between sales and profit?
2. Why use `GROUP BY` in SQL?
3. How would you handle missing values and duplicate records?
4. What does profit margin tell a business?
5. Why use a star schema / relationships in Power BI?
6. What is the difference between a calculated column and a measure in DAX?
7. How would you investigate a sudden drop in monthly sales?
